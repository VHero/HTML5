<?php
$user = "";
$pass = "";
$db = ""; //Something like "mysql:host=localhost;dbname=ssechat"
?>