For chapter 9 you'll find a copy of the Geometry Destroyer (GD) application. 
This app is built exclusively built for Google Chrome although it may work in other browsers.

Does your computer support WebGL???
In Chrome you can see the compatability details of your graphics card by typing into the 
address bar chrome://gpu and pressing enter. Then look for WebGL under Graphics Feature Status.
Just because it says your graphics card works doesn't mean that your browser will run the game
smoothly or at all. But is a good indicator for support. Some people have hacked their cards
to get this working. But this is not recommended and if you blow up your computer its your own
fault.

To run GD:
1. Navigate into the geometry_destroyer file
2. Load up index.html and you should be good to go (Chrome recommended)

NOTE: If you aren't seeing any WebGL in Chrome try another computer with a better graphics card.
Reason being graphics cards released in the past couple years are the only GPUs with the necessary drivers.